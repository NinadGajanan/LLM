# Lifting Line Model
 Vorticity based model for approximating performance of a propeller rotor
